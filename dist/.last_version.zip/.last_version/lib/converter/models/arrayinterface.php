<?php

namespace Awz\RichContent\Converter\Models;

interface ArrayInterface
{
    /**
     * @return array
     */
    public function toArray(): array;
}
