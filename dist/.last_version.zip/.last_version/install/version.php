<?
$arModuleVersion = array(
	"VERSION" => "1.0.8",
	"VERSION_DATE" => "2024-10-04 13:49:00"
);
?>