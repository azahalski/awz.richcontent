<?
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2024-05-06 11:45:00"
);
?>