<?
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2024-05-15 12:55:00"
);
?>