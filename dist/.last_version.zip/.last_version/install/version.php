<?
$arModuleVersion = array(
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2024-10-01 15:42:00"
);
?>